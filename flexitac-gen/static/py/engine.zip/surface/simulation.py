"""The sensor as a simulator loads it: ``rss-flexitac-sensor/v1``.

A mapped build (:func:`surface.place.map_route`) states every taxel on the part.  A simulator
that lays a flat FlexiTac film on a finger needs less, and in a form it can carry to any pitch:
the grid (row 1 / column 1's centre and the steps to the next row and column, fitted to the
taxels by least squares), the columns each row keeps (``matrix.mask``'s spans, 1-based and
inclusive, row 1 the tip's), the face's outline and the part mesh's SHA-256.  RoboSimStudio
reads this file as it is (``rss.flexitac(sensor="<file>")``): the mesh's SHA-256 finds the
robot hand that carries the part, and the film then has this sensor's taxels, only these, on that
hand's finger.  The format is RoboSimStudio's own (``robosimstudio_materials/flexitac/gen.py``),
which also ships the Library's designs in it.

A face that is not flat is still written: ``flat_within_mm`` says how far the taxels miss a flat
grid (the I2RT fingertip's developable face, 0.34 mm), and a simulator that lays films flat
refuses one beyond its own tolerance (RoboSimStudio: 1 mm).
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

FORMAT = "rss-flexitac-sensor/v1"
LOAD = 'rss.flexitac(sensor="<this file>")'


def _solve3(m: Sequence[Sequence[float]], v: Sequence[float]) -> list:
    """``m x = v`` for a 3 x 3 ``m`` (Gaussian elimination with partial pivoting)."""
    a = [list(map(float, row)) + [float(b)] for row, b in zip(m, v)]
    for col in range(3):
        pivot = max(range(col, 3), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-12:
            raise ValueError("the taxel grid is degenerate (fewer than two rows or two columns of taxels)")
        a[col], a[pivot] = a[pivot], a[col]
        for r in range(3):
            if r != col:
                f = a[r][col] / a[col][col]
                a[r] = [x - f * y for x, y in zip(a[r], a[col])]
    return [a[i][3] / a[i][i] for i in range(3)]


def lattice(taxels: Sequence[Mapping[str, Any]]) -> tuple:
    """``(origin, row_step, col_step, miss)`` [mm]: ``xyz ~ origin + (row - 1) row_step + (column - 1) col_step``.

    By least squares over every taxel; ``miss`` is the worst taxel's distance from the fitted grid.
    """
    rows = [float(t["row"]) - 1.0 for t in taxels]
    cols = [float(t["column"]) - 1.0 for t in taxels]
    n = float(len(taxels))
    sr, sc = sum(rows), sum(cols)
    m = [[n, sr, sc], [sr, sum(r * r for r in rows), sum(r * c for r, c in zip(rows, cols))],
         [sc, sum(r * c for r, c in zip(rows, cols)), sum(c * c for c in cols)]]  # fmt: skip
    coef = []
    for k in range(3):
        x = [float(t["xyz_mm"][k]) for t in taxels]
        coef.append(_solve3(m, [sum(x), sum(r * v for r, v in zip(rows, x)), sum(c * v for c, v in zip(cols, x))]))
    origin = [coef[k][0] for k in range(3)]
    row_step = [coef[k][1] for k in range(3)]
    col_step = [coef[k][2] for k in range(3)]
    miss = 0.0
    for t, r, c in zip(taxels, rows, cols):
        p = [origin[k] + r * row_step[k] + c * col_step[k] for k in range(3)]
        miss = max(miss, math.dist(p, [float(x) for x in t["xyz_mm"]]))
    return origin, row_step, col_step, miss


def sensor_config(
    mapped: Mapping[str, Any],
    design: Mapping[str, Any],
    face_xyz: Sequence[Sequence[float]] = (),
    *,
    ident: str = "",
    part: str = "",
    source: str = "",
) -> dict:
    """The ``rss-flexitac-sensor/v1`` document of a mapped build.

    ``mapped`` is :func:`surface.place.map_route`'s result (its taxels, readout and mesh), ``design``
    the build's design (its matrix), ``face_xyz`` the selected face's outline [mm, the STL's frame].
    ``ident`` names it (the build id when empty); ``part`` is the Library part it was fitted to,
    when it was.
    """
    matrix = design["matrix"]
    R, C = int(matrix["rows"]), int(matrix["columns"])
    taxels = mapped["taxels"]
    readout = mapped.get("readout") or {}
    spans = readout.get("row_spans") or [[1, C]] * R
    origin, row_step, col_step, miss = lattice(taxels)
    normal = [sum(float(t["normal"][k]) for t in taxels) for k in range(3)]
    length = math.sqrt(sum(x * x for x in normal)) or 1.0
    build_id = str(mapped["build_id"])
    r6 = lambda v: [round(float(x), 6) for x in v]  # noqa: E731
    return {
        "format": FORMAT,
        "id": ident or build_id,
        "part": part,
        "source": source or f"FlexiTac-Gen build {build_id}",
        "mesh_sha256": str(mapped["mesh"]["sha256"]),
        "build_id": build_id,
        "pitch_mm": float(matrix["pitch_x_mm"]),
        "rows": R,
        "cols": C,
        "taxels": len(taxels),
        "row_spans": [[int(a), int(b)] for a, b in spans],
        "lattice_mm": {"origin": r6(origin), "row_step": r6(row_step), "col_step": r6(col_step), "normal": r6(x / length for x in normal)},
        "face_mm": [[round(float(c), 4) for c in p] for p in face_xyz],
        "flat_within_mm": round(miss, 4),
        "use": {
            "for": "simulation",
            "simulator": "RoboSimStudio (FlexiTac films)",
            "load": LOAD,
            "note": "The film carries this sensor's taxels only, on the robot hand whose finger is this part (matched by "
            "mesh_sha256); a part no hand carries is refused. Taxel size and layout are this build's.",
        },
    }
